﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchoolBus.WpfApp
{
    /// <summary>
    /// Interaction logic for Login_Page.xaml
    /// </summary>
    public partial class Login_Page : Page
    {
        public Login_Page()
        {
            InitializeComponent();
        }

        string code = "";
            Random random = new Random();
        int randomNumber=0;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            a.Visibility= Visibility.Visible;
            Txt_Copy.Visibility= Visibility.Visible;
            Loginbtn.Visibility= Visibility.Visible;
            randomNumber = random.Next(100000, 999999);
            code= randomNumber.ToString();

            SendEmail("nazlirzazade8@gmail.com",Txt.Text,"Your verification code : ", code);
        }

        private void Loginbtn_Click(object sender, RoutedEventArgs e)
        {
            if (code == randomNumber.ToString()) { MainContent.Content = new(); }
            else 
            {
                MessageBox.Show("Wrong code!try again");
                a.Visibility = Visibility.Hidden;
                Txt_Copy.Visibility = Visibility.Hidden;
                Loginbtn.Visibility = Visibility.Hidden;
            }
        }

        public void SendEmail(string from, string to, string subject, string body)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress(from);
                mail.To.Add(to);
                mail.Subject = subject;
                mail.Body = body;

                smtpClient.Port = 587;
                smtpClient.Credentials = new NetworkCredential("Nazlirzazade8@gmail.com", "Bts8116764");
                smtpClient.EnableSsl = true;

                smtpClient.Send(mail);
                Console.WriteLine("Email sent successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to send email. Error: " + ex.Message);
            }
        }
    }
}
