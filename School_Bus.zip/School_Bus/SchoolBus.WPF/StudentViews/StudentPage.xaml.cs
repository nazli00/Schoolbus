﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using SchoolBus.WPF.DTOs;
using SchoolBus.WPF.SchoolBusDTOContext;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace SchoolBus.WPF.StudentViews
{
    /// <summary>
    /// Interaction logic for StudentPage.xaml
    /// </summary>
    public partial class StudentPage : Page
    {
        public ObservableCollection<StudentDTO> Students { get; set; } = new ObservableCollection<StudentDTO>();
        static SchoolBusDBContext Context = new SchoolBusDBContext();
        StudentDTO a = new();
        public StudentPage(DTOContext context_)
        {
            InitializeComponent();
            Students=DTOContext.students;
            DataContext = this;


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddStudent addstudent = new AddStudent();
            addstudent.Closed += (s, args) =>
            {
                StudentDTO updatedDto = addstudent.Dto;
                Students.Add(updatedDto);
                updatedDto.Getall(Context, Students);

                DTOContext.students = Students;


            };
            addstudent.Show();
        }

        private void Remove(object sender, RoutedEventArgs e)
        {
            if (studentListView.SelectedItem is StudentDTO selectedStudent)
            {
                Students.Remove(selectedStudent);
            }

            DTOContext.students = Students;

        }

    }
}