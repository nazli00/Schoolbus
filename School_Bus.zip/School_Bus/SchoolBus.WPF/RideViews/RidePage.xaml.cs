﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using SchoolBus.WPF.DriverViews;
using SchoolBus.WPF.DTOs;
using SchoolBus.WPF.SchoolBusDTOContext;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace SchoolBus.WPF.RideViews
{
    /// <summary>
    /// Interaction logic for RidePage.xaml
    /// </summary>
    public partial class RidePage : Page
    {
        public ObservableCollection<RideDTO> Rides { get; set; } = new ObservableCollection<RideDTO>();
        static SchoolBusDBContext Context = new SchoolBusDBContext();
            RideDTO a = new();
        public RidePage(DTOContext context_)
        {
            InitializeComponent();
            Rides = DTOContext.Rides;

            DataContext = this;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddRide addRide = new AddRide();
            addRide.Closed += (s, args) =>
            {
                RideDTO updatedDto = addRide.Dto;
                Rides.Add(updatedDto);
                updatedDto.Getall(Context, Rides);

                DTOContext.Rides = Rides;
            };
            addRide.Show();
        }

        private void Remove(object sender, RoutedEventArgs e)
        {
            if (selectedRide.SelectedItem is RideDTO selectedStudent)
            {
                Rides.Remove(selectedStudent);
            }

            DTOContext.Rides = Rides;

        }
    }
}
