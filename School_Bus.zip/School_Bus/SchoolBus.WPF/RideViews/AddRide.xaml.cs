﻿using SchoolBus.Model.Entites.Concretes;
using SchoolBus.WPF.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchoolBus.WPF.RideViews
{
    /// <summary>
    /// Interaction logic for AddRide.xaml
    /// </summary>
    public partial class AddRide : Window
    {
        public RideDTO Dto { get; private set; } = new RideDTO();
        public AddRide()
        {
            InitializeComponent();
        }

        private void Add(object sender, RoutedEventArgs e)
        {
            Dto = Dto.Add_(starttime, endtime, ID, car, driver, route);
            Close();
        }
    }
}
