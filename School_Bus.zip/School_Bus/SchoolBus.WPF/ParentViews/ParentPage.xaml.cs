﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using SchoolBus.WPF.DTOs;
using SchoolBus.WPF.SchoolBusDTOContext;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
namespace SchoolBus.WPF.ParentViews
{
    /// <summary>
    /// Interaction logic for ParentPage.xaml
    /// </summary>
    public partial class ParentPage : Page
    {
        public ObservableCollection<ParentDTO> Parents { get; set; } = new ObservableCollection<ParentDTO>();
        
        static SchoolBusDBContext Context=new SchoolBusDBContext();
        ParentDTO a = new();
        public ParentPage(DTOContext context_)
        {
            InitializeComponent();
            Parents = DTOContext.parents;

            DataContext = this;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddParent addRide = new AddParent();
            addRide.Closed += (s, args) =>
            {
                ParentDTO updatedDto = addRide.Dto;
                Parents.Add(updatedDto);
                updatedDto.Getall(Context, Parents);

                DTOContext.parents = Parents;

            };
            addRide.Show();
        }

        private void Remove(object sender, RoutedEventArgs e)
        {
            if (selectedparent.SelectedItem is ParentDTO selectedStudent)
            {
                Parents.Remove(selectedStudent);
            }

            DTOContext.parents = Parents;

        }

    }
}
