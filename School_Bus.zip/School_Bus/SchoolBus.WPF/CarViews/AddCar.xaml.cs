﻿using SchoolBus.WPF.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SchoolBus.WPF.CarViews
{
    /// <summary>
    /// Interaction logic for AddCar.xaml
    /// </summary>
    public partial class AddCar : Window
    {
        public CarDTO Dto { get; private set; } = new CarDTO();
        public AddCar()
        {
            InitializeComponent();
        }


        private void Add(object sender, RoutedEventArgs e)
        {
            Dto = Dto.Add_(ID, bus_num_, driver_,num_seats_);

            Close();
        }
    }
}
