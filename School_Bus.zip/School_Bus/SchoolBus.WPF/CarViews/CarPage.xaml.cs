﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using SchoolBus.WPF.ClassViews;
using SchoolBus.WPF.DTOs;
using SchoolBus.WPF.SchoolBusDTOContext;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchoolBus.WPF.CarViews
{
    /// <summary>
    /// Interaction logic for CarPage.xaml
    /// </summary>
    public partial class CarPage : Page
    {
        public ObservableCollection<CarDTO> cars { get; set; } = new ObservableCollection<CarDTO>();

        static SchoolBusDBContext Context = new SchoolBusDBContext();
        CarDTO a = new();
        public CarPage(DTOContext context_)
        {
            InitializeComponent();
            cars = DTOContext.Cars;

            DataContext = this;

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddCar addCar = new AddCar();
            addCar.Closed += (s, args) =>
            {
                CarDTO updatedDto = addCar.Dto;
                cars.Add(updatedDto);
                updatedDto.Getall(Context, cars);

                DTOContext.Cars=cars;
            };
            addCar.Show();
        }

        private void Remove(object sender, RoutedEventArgs e)
        {
            // Check if a student is selected
            if (selectedcar.SelectedItem is CarDTO selectedStudent)
            {
                // Remove the selected student from the Students collection
                cars.Remove(selectedStudent);
            }

            DTOContext.Cars = cars;


        }
    }
}
