﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.WPF.CarViews;
using SchoolBus.WPF.ClassViews;
using SchoolBus.WPF.DriverViews;
using SchoolBus.WPF.ParentViews;
using SchoolBus.WPF.RideViews;
using SchoolBus.WPF.SchoolBusDTOContext;
using SchoolBus.WPF.StudentViews;
using System.Windows;
using System.Windows.Controls;

namespace SchoolBus.WPF;

/// <summary>
/// Interaction logic for MainPage.xaml
/// </summary>
public partial class MainPage : Page
{
    public static DTOContext? contextdb {  get; set; }=new DTOContext();

    public MainPage()
    {
        InitializeComponent();
    }

    private void ride(object sender, RoutedEventArgs e)
    {
        MainContent.Content = new RidePage(contextdb!);
    }

    private void class_(object sender, RoutedEventArgs e)
    {
        MainContent.Content = new ClassPage(contextdb!);
    }

    private void student(object sender, RoutedEventArgs e)
    {
        MainContent.Content = new StudentPage(contextdb!);
    }

    private void parent(object sender, RoutedEventArgs e)
    {
        MainContent.Content = new ParentPage(contextdb!);
    }

    private void driver(object sender, RoutedEventArgs e)
    {
        MainContent.Content = new DriverPage(contextdb!);

    }

    private void car(object sender, RoutedEventArgs e)
    {
        MainContent.Content = new CarPage(contextdb!);
    }
}
