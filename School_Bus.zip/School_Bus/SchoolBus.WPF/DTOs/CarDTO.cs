﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using System.Collections.ObjectModel;

namespace SchoolBus.WPF.DTOs;

public class CarDTO
{
    public int id { get; set; }
    public string? bus_num { get; set; }
    public int driver { get; set; }
    public int num_seats { get; set; }
    public void Getall(SchoolBusDBContext context, ObservableCollection<CarDTO> Car_)
    {
        List<Car>? carDTOs = context.Cars_?.ToList();

        foreach (var car in carDTOs!)
        {
            Car_.Add(new CarDTO
            {
                id = car.id,
                bus_num = car.bus_num,
                driver = car.driver,
                num_seats = car.num_seats,
            }); ;
        }
    }

    public CarDTO Add_(dynamic id_, dynamic busnum, dynamic driver_id ,dynamic num_seats)
    {
        int id = int.Parse(id_.Text);
        string busnum_ = busnum.Text.ToString();
        int driver = int.Parse(driver_id.Text);
        int num_s = int.Parse(num_seats.Text);



        var newCar = new CarDTO
        {
            id = id,
            bus_num = busnum_,
            driver = driver,
            num_seats=num_s,
        };

        return newCar;
    }
}
