﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using System.Collections.ObjectModel;

namespace SchoolBus.WPF.DTOs;

public class ClassDTO
{
    public int id { get; set; }
    public int num_students { get; set; }
    public int num_parents { get; set; }


    public void Getall(SchoolBusDBContext context, ObservableCollection<ClassDTO> Class_)
    {
        List<Class>? classDTOs = context.Classes_?.ToList();

        foreach (var class_ in classDTOs!)
        {
            Class_.Add(new ClassDTO
            {
                id = class_.id,
                num_students=class_.num_students,
                num_parents=class_.num_parents,
            }); ;
        }
    }

    public ClassDTO Add_(dynamic id_, dynamic studentnum, dynamic parentnum)
    {
        int id = int.Parse(id_.Text);
        int s_num = int.Parse(studentnum.Text);
        int p_num = int.Parse(parentnum.Text);


        var newClass = new ClassDTO
        {
            id = id,
            num_students = s_num,
            num_parents = p_num,
        };

        return newClass;
    }
}
