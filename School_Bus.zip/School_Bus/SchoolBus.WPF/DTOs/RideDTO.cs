﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using System.Collections.ObjectModel;
using System.Globalization;

namespace SchoolBus.WPF.DTOs;

public class RideDTO
{
    public int id { get; set; }
    public DateTime start_time { get; set; }
    public DateTime end_time { get; set; }
    public int route_ { get; set; }
    public int car { get; set; }
    public int driver { get; set; }


    public void Getall(SchoolBusDBContext context  ,ObservableCollection<RideDTO> Rides)
    {
        List<Ride>? rideDTOs = context.Rides_?.ToList();

        foreach (var ride in rideDTOs!)
        {
            Rides.Add(new RideDTO
            {
                id = ride.id,
                start_time = ride.start_time,
                end_time = ride.end_time,
                driver = ride.driver,
                route_ = ride.route_,
                car = ride.car

            }); ;
        }
    }


    public RideDTO Add_(dynamic starttime, dynamic endtime,dynamic ID,dynamic car,dynamic driver,dynamic route)
    {
        DateTime a = DateTime.ParseExact(starttime.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
        DateTime b = DateTime.ParseExact(endtime.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
        int id = int.Parse(ID.Text);
        int car_ = int.Parse(car.Text);
        int driver_ = int.Parse(driver.Text);
        int route_ = int.Parse(route.Text);

        var newride = new RideDTO
        {
            id = id,
            start_time = a,
            end_time = b,
            car = car_,
            driver = driver_,
            route_ = route_,
        };

        return newride;
    } 
}
