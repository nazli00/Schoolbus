﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using System.Collections.ObjectModel;

namespace SchoolBus.WPF.DTOs;

public class StudentDTO
{
    public int id { get; set; }
    public string? name { get; set; }
    public string? surname { get; set; }
    public int age { get; set; }
    public int parent_ { get; set; }
    public int classid { get; set; }

    public void Getall(SchoolBusDBContext context, ObservableCollection<StudentDTO> Students)
    {
        List<Student>? studentDTOs = context.Students_?.ToList();

        foreach (var student in studentDTOs!)
        {
            Students.Add(new StudentDTO
            {
                id = student.id,
                name = student.name,
                surname = student.surname,
                age = student.age,
                parent_=student.parent_,
                classid = student.classid
            });
        }
    }

    public StudentDTO Add_(dynamic id_, dynamic name_, dynamic surname_, dynamic age_,dynamic parentid,dynamic classid_)
    {
        int id = int.Parse(id_.Text);
        string name = name_.Text.ToString();
        string surname = surname_.Text.ToString();
        int age = int.Parse(age_.Text);
        int parent = int.Parse(parentid.Text);
        int classid = int.Parse(classid_.Text);


        var newcar= new StudentDTO
        {
            id = id,
            name = name,
            surname = surname,
            age = age,
            parent_ = parent ,
            classid = classid
        };

        return newcar;
    }
}
