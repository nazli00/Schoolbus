﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using System.Collections.ObjectModel;
using System.Globalization;

namespace SchoolBus.WPF.DTOs;

public class DriverDTO
{
    public int id { get; set; }
    public string? name { get; set; }
    public string? surname { get; set; }
    public int age { get; set; }

    public void Getall(SchoolBusDBContext context, ObservableCollection<DriverDTO> Drivers)
    {
        List<Driver>? driverDTOs = context.Drivers_?.ToList();

        foreach (var driver in driverDTOs!)
        {
            Drivers.Add(new DriverDTO
            {
                id = driver.id,
                name=driver.name,
                surname = driver.surname,
                age = driver.age,
            }); ;
        }
    }

    public DriverDTO Add_(dynamic id_, dynamic name_, dynamic surname_, dynamic age_)
    {
        int id = int.Parse(id_.Text);
        string name = name_.Text.ToString();
        string surname = surname_.Text.ToString();
        int age = int.Parse(age_.Text);

        var newdriver = new DriverDTO
        {
            id = id,
            name=name,
            surname=surname, age=age,
        };

        return newdriver;
    }
}
