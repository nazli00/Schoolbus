﻿using SchoolBus.WPF.DTOs;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBus.WPF.SchoolBusDTOContext;

public class DTOContext
{
    public static ObservableCollection<RideDTO> Rides { get; set; } = new ObservableCollection<RideDTO>();
    public static ObservableCollection<DriverDTO> drivers { get; set; } = new ObservableCollection<DriverDTO>();
    public static ObservableCollection<StudentDTO> students { get; set; } = new ObservableCollection<StudentDTO>();
    public static ObservableCollection<ParentDTO> parents { get; set; } = new ObservableCollection<ParentDTO>();
    public static ObservableCollection<ClassDTO> classes { get; set; } = new ObservableCollection<ClassDTO>();
    public static ObservableCollection<CarDTO> Cars { get; set; } = new ObservableCollection<CarDTO>();

}
