﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using SchoolBus.WPF.DTOs;
using SchoolBus.WPF.SchoolBusDTOContext;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace SchoolBus.WPF.DriverViews
{
    /// <summary>
    /// Interaction logic for DriverPage.xaml
    /// </summary>
    public partial class DriverPage : Page
    {
        public ObservableCollection<DriverDTO> drivers { get; set; } = new ObservableCollection<DriverDTO>();

         static SchoolBusDBContext Context = new SchoolBusDBContext();
            DriverDTO a = new();
        public DriverPage(DTOContext context_)
        {
            InitializeComponent();
            drivers = DTOContext.drivers;

            DataContext = this;

        }

        private void Addbtn(object sender, RoutedEventArgs e)
        {
            AddDriver addDriver = new AddDriver();
            addDriver.Closed += (s, args) =>
            {
                DriverDTO updatedDto = addDriver.Dto;
                drivers.Add(updatedDto);
                updatedDto.Getall(Context, drivers);
                List<Driver>? driverDTOs = Context.Drivers_?.ToList();

                DTOContext.drivers = drivers;

            };
            addDriver.Show();
            
        }

        private void Remove(object sender, RoutedEventArgs e)
        {
            if (Selecteddriver.SelectedItem is DriverDTO selectedStudent)
            {
                drivers.Remove(selectedStudent);
            }

            DTOContext.drivers = drivers;

        }
    }
}
