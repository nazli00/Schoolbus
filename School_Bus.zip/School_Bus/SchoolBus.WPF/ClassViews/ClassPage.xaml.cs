﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.Model.Entites.Concretes;
using SchoolBus.WPF.DriverViews;
using SchoolBus.WPF.DTOs;
using SchoolBus.WPF.SchoolBusDTOContext;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SchoolBus.WPF.ClassViews
{
    /// <summary>
    /// Interaction logic for ClassPage.xaml
    /// </summary>
    public partial class ClassPage : Page
    {
        public ObservableCollection<ClassDTO> classes { get; set; } = new ObservableCollection<ClassDTO>();

        static SchoolBusDBContext Context = new SchoolBusDBContext();
        ClassDTO a = new();
        public ClassPage(DTOContext context_)
        {
            InitializeComponent();
            classes = DTOContext.classes;

            DataContext = this;

        }

        private void Addbtn(object sender, RoutedEventArgs e)
        {
            AddClass addClass = new AddClass();
            addClass.Closed += (s, args) =>
            {
                ClassDTO updatedDto = addClass.Dto;
                classes.Add(updatedDto);
                updatedDto.Getall(Context, classes);

                DTOContext.classes = classes;

            };
            addClass.Show();

        }

        private void Remove(object sender, RoutedEventArgs e)
        {
            if (selectedclass.SelectedItem is ClassDTO selectedStudent)
            {
                classes.Remove(selectedStudent);
            }
            DTOContext.classes = classes;

        }
    }
}
