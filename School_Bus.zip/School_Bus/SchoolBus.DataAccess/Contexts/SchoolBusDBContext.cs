﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Contexts;

public class SchoolBusDBContext:DbContext
{

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {

        string Constr = "Data Source=DESKTOP-JN5TK9A\\SQLEXPRESS01;Initial Catalog=projct;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;";

        optionsBuilder.UseSqlServer(Constr);
        base.OnConfiguring(optionsBuilder);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);

        modelBuilder.Entity<Student>()
            .HasOne(s => s.Parent)
            .WithMany(p => p.Students)
            .HasForeignKey(s => s.parent_);
        
        modelBuilder.Entity<Student>()
            .HasOne(I => I.Class)
            .WithMany(v => v.Students)
            .HasForeignKey(I => I.classid);

        modelBuilder.Entity<Ride>()
            .HasOne(a => a.Route)
            .WithMany(e => e.Rides)
            .HasForeignKey(a => a.route_);

        modelBuilder.Entity<Ride>()
            .HasOne(r => r.Car)
            .WithMany(c => c.Rides)
            .HasForeignKey(r => r.car);

        modelBuilder.Entity<Ride>()
            .HasOne(ri => ri.Driver)
            .WithMany(ca => ca.Rides)
            .HasForeignKey(ri => ri.driver);

        modelBuilder.Entity<Car>()
            .HasOne(c => c.Driver)
            .WithMany(d => d.Cars)
            .HasForeignKey(c => c.driver);

        modelBuilder.Entity<BusStop>()
            .HasOne(bs => bs.Route)
            .WithMany(r => r.BusStops)
            .HasForeignKey(bs => bs.route);

        base.OnModelCreating(modelBuilder);
    }

    public DbSet<BusStop>? BusStops_ { get; set; }
    public DbSet<Class>? Classes_ { get; set; }
    public DbSet<Car>? Cars_ { get; set; }
    public DbSet<Student>? Students_ { get; set; }
    public DbSet<Parent>? Parents_ { get; set; }
    public DbSet<Route>? Routes_ { get; set; }
    public DbSet<Ride>? Rides_ { get; set; }
    public DbSet<Driver>? Drivers_ { get; set; }




}
