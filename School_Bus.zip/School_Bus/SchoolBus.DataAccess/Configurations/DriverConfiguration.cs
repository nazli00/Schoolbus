﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Configurations;

internal class DriverConfiguration : IEntityTypeConfiguration<Driver>
{
    public void Configure(EntityTypeBuilder<Driver> builder)
    {
        builder.HasKey(I => I.id);
        builder.Property(I => I.id).UseIdentityColumn();
        builder.Property(I => I.name).HasMaxLength(50).IsRequired();
        builder.ToTable("Drivers");
    }

}
