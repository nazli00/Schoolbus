﻿

using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Configurations;

internal class ClassConfiguration : IEntityTypeConfiguration<Class>
{
    public void Configure(EntityTypeBuilder<Class> builder)
    {
        builder.HasKey(I => I.id);
        builder.Property(I => I.id).UseIdentityColumn();
        builder.ToTable("Classes");
    }

}