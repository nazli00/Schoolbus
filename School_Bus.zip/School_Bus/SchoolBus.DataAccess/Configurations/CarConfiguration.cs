﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Configurations;

internal class CarConfiguration : IEntityTypeConfiguration<Car>
{
    public void Configure(EntityTypeBuilder<Car> builder)
    {
        builder.HasKey(I => I.id);
        builder.Property(I => I.id).UseIdentityColumn();
        builder.ToTable("Cars");
    }

}