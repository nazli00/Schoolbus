﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using SchoolBus.Model.Entites.Concretes;
namespace SchoolBus.DataAccess.Configurations;

internal class RideConfiguration : IEntityTypeConfiguration<Ride>
{
    public void Configure(EntityTypeBuilder<Ride> builder)
    {
        builder.HasKey(I => I.id);
        builder.Property(I => I.id).UseIdentityColumn();
        builder.ToTable("Rides");
    }
}
