﻿
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Configurations;

internal class BusStopConfiguration : IEntityTypeConfiguration<BusStop>
{
    public void Configure(EntityTypeBuilder<BusStop> builder)
    {
        builder.HasKey(I => I.id);
        builder.Property(I => I.id).UseIdentityColumn();
        builder.Property(I => I.route);
        builder.Property(I => I.name).HasMaxLength(50).IsRequired();
        builder.ToTable("Bus_Stops");
    }


}