﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.DataAccess.Reposities.Abstracts;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Concretes;

public class RideRepository : IRideRepository
{

    private readonly SchoolBusDBContext _schoolbusdbcontext;

    public RideRepository()
    {
        _schoolbusdbcontext = new SchoolBusDBContext();
    }
    public void Add(Ride entity)
    {
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        _schoolbusdbcontext.Rides_?.Add(entity);
    }
    public void Update(Ride entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Rides_?.Update(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public void Delete(Ride entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Rides_?.Remove(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public ICollection<Ride>? GetAll()
    {
        return _schoolbusdbcontext.Rides_?.ToList();
    }

    public Ride? GetById(int id)
    {
        return _schoolbusdbcontext.Rides_?.FirstOrDefault(a => a.id == id);
    }
    public void save()
    {
        _schoolbusdbcontext.SaveChanges();
    }
}
