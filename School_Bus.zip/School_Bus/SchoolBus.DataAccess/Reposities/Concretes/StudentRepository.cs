﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.DataAccess.Reposities.Abstracts;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Concretes;

public class StudentRepository:IStudentRepository
{
    private readonly SchoolBusDBContext _schoolbusdbcontext;

    public StudentRepository()
    {
        _schoolbusdbcontext = new SchoolBusDBContext();
    }
    public void Add(Student entity)
    {
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        _schoolbusdbcontext.Students_?.Add(entity);
    }
    public void Update(Student entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Students_?.Update(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public void Delete(Student entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Students_?.Remove(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public ICollection<Student>? GetAll()
    {
        return _schoolbusdbcontext.Students_?.ToList();
    }

    public Student? GetById(int id)
    {
        return _schoolbusdbcontext.Students_?.FirstOrDefault(a => a.id == id);
    }
    public void save()
    {
        _schoolbusdbcontext.SaveChanges();
    }
}
