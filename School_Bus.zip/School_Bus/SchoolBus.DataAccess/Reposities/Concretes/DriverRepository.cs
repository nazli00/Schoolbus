﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.DataAccess.Reposities.Abstracts;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Concretes;

internal class DriverRepository:IDriverRepository
{

    private readonly SchoolBusDBContext _schoolbusdbcontext;

    public DriverRepository()
    {
        _schoolbusdbcontext = new SchoolBusDBContext();
    }
    public void Add(Driver entity)
    {
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        _schoolbusdbcontext.Drivers_?.Add(entity);
    }
    public void Update(Driver entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Drivers_?.Update(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public void Delete(Driver entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Drivers_?.Remove(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public ICollection<Driver>? GetAll()
    {
        return _schoolbusdbcontext.Drivers_?.ToList();
    }

    public Driver? GetById(int id)
    {
        return _schoolbusdbcontext.Drivers_?.FirstOrDefault(a => a.id == id);
    }
    public void save()
    {
        _schoolbusdbcontext.SaveChanges();
    }
}
