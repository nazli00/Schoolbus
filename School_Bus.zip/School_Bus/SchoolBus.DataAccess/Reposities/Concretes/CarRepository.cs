﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.DataAccess.Reposities.Abstracts;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Concretes;

public class CarRepository:ICarRepository
{

    private readonly SchoolBusDBContext _schoolbusdbcontext;

    public CarRepository()
    {
        _schoolbusdbcontext = new SchoolBusDBContext();
    }
    public void Add(Car entity)
    {
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        _schoolbusdbcontext.Cars_?.Add(entity);
    }
    public void Update(Car entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Cars_?.Update(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public void Delete(Car entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Cars_?.Remove(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public ICollection<Car>? GetAll()
    {
        return _schoolbusdbcontext.Cars_?.ToList();
    }

    public Car? GetById(int id)
    {
        return _schoolbusdbcontext.Cars_?.FirstOrDefault(a => a.id == id);
    }
    public void save()
    {
        _schoolbusdbcontext.SaveChanges();
    }
}
