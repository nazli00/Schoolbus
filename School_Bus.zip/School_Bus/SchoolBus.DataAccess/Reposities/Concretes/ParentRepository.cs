﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.DataAccess.Reposities.Abstracts;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Concretes;

public class ParentRepository:IParentRepository
{
    private readonly SchoolBusDBContext _schoolbusdbcontext;

    public ParentRepository()
    {
        _schoolbusdbcontext = new SchoolBusDBContext();
    }
    public void Add(Parent entity)
    {
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        _schoolbusdbcontext.Parents_?.Add(entity);
    }
    public void Update(Parent entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Parents_?.Update(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public void Delete(Parent entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Parents_?.Remove(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public ICollection<Parent>? GetAll()
    {
        return _schoolbusdbcontext.Parents_?.ToList();
    }

    public Parent? GetById(int id)
    {
        return _schoolbusdbcontext.Parents_?.FirstOrDefault(a => a.id == id);
    }
    public void save()
    {
        _schoolbusdbcontext.SaveChanges();
    }
}
