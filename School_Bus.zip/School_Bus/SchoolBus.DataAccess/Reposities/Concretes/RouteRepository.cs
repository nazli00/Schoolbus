﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.DataAccess.Reposities.Abstracts;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Concretes;

public class RouteRepository:IRouteRepository
{

    private readonly SchoolBusDBContext _schoolbusdbcontext;

    public RouteRepository()
    {
        _schoolbusdbcontext = new SchoolBusDBContext();
    }
    public void Add(Route entity)
    {
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        _schoolbusdbcontext.Routes_?.Add(entity);
    }
    public void Update(Route entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Routes_?.Update(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public void Delete(Route entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Routes_?.Remove(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public ICollection<Route>? GetAll()
    {
        return _schoolbusdbcontext.Routes_?.ToList();
    }

    public Route? GetById(int id)
    {
        return _schoolbusdbcontext.Routes_?.FirstOrDefault(a => a.id == id);
    }
    public void save()
    {
        _schoolbusdbcontext.SaveChanges();
    }
}