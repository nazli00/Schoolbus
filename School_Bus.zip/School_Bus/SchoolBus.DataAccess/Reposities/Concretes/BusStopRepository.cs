﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.DataAccess.Reposities.Abstracts;
using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Concretes;
public class BusStopRepository : IBusStopRepository
{
    private readonly SchoolBusDBContext _schoolbusdbcontext;
    
    public BusStopRepository()
    {
        _schoolbusdbcontext = new SchoolBusDBContext();
    }
    public void Add(BusStop entity)
    {
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        _schoolbusdbcontext.BusStops_?.Add(entity);
    }
    public void Update(BusStop entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.BusStops_?.Update(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public void Delete(BusStop entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.BusStops_?.Remove(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public ICollection<BusStop>? GetAll()
    {
        return _schoolbusdbcontext.BusStops_?.ToList();
    }

    public BusStop? GetById(int id)
    {
        return _schoolbusdbcontext.BusStops_?.FirstOrDefault(a => a.id == id);
    }
    public void save()
    {
        _schoolbusdbcontext.SaveChanges();
    }
}
