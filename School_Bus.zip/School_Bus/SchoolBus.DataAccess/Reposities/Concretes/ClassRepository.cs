﻿using SchoolBus.DataAccess.Contexts;
using SchoolBus.DataAccess.Reposities.Abstracts;
using SchoolBus.Model.Entites.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBus.DataAccess.Reposities.Concretes;

public class ClassRepository:IClassRepository
{

    private readonly SchoolBusDBContext _schoolbusdbcontext;

    public ClassRepository()
    {
        _schoolbusdbcontext = new SchoolBusDBContext();
    }
    public void Add(Class entity)
    {
        if (entity == null) throw new ArgumentNullException(nameof(entity));

        _schoolbusdbcontext.Classes_?.Add(entity);
    }
    public void Update(Class entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Classes_?.Update(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public void Delete(Class entity)
    {
        if (entity == null) throw new ArgumentNullException();
        try
        {
            _schoolbusdbcontext.Classes_?.Remove(entity);
        }
        catch (Exception)
        {
            throw new Exception("Data is not found");
        }
    }
    public ICollection<Class>? GetAll()
    {
        return _schoolbusdbcontext.Classes_?.ToList();
    }

    public Class? GetById(int id)
    {
        return _schoolbusdbcontext.Classes_?.FirstOrDefault(a => a.id == id);
    }
    public void save()
    {
        _schoolbusdbcontext.SaveChanges();
    }
}
