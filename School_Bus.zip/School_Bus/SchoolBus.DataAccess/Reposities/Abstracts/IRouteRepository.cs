﻿using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Abstracts;

public interface IRouteRepository
{
    ICollection<Route>? GetAll();
    Route? GetById(int id);
    void Add(Route student);
    void Update(Route student);
    void Delete(Route student);

    void save();
}
