﻿using SchoolBus.Model.Entites.Concretes;
namespace SchoolBus.DataAccess.Reposities.Abstracts;

public interface IStudentRepository
{

    ICollection<Student>? GetAll();
    Student? GetById(int id);
    void Add(Student student);
    void Update(Student student);
    void Delete(Student student);

    void save();
}
