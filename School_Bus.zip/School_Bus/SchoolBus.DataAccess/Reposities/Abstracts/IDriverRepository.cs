﻿using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Abstracts;

public interface IDriverRepository
{
    ICollection<Driver>? GetAll();
    Driver? GetById(int id);
    void Add(Driver student);
    void Update(Driver student);
    void Delete(Driver student);

    void save();
}
