﻿using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Abstracts;

public interface IRideRepository
{
    ICollection<Ride>? GetAll();
    Ride? GetById(int id);
    void Add(Ride student);
    void Update(Ride student);
    void Delete(Ride student);

    void save();
}
