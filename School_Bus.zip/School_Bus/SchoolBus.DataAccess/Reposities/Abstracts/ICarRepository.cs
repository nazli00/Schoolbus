﻿using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Abstracts;

public interface ICarRepository
{
    ICollection<Car>? GetAll();
    Car? GetById(int id);
    void Add(Car student);
    void Update(Car student);
    void Delete(Car student);

    void save();
}
