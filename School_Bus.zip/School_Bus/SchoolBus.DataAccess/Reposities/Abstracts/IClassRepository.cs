﻿using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Abstracts;

public interface IClassRepository
{

    ICollection<Class>? GetAll();
    Class? GetById(int id);
    void Add(Class student);
    void Update(Class student);
    void Delete(Class student);

    void save();
}
