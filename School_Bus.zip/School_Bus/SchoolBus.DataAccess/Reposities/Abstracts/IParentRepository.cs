﻿

using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Abstracts;

public interface IParentRepository
{
    ICollection<Parent>? GetAll();
    Parent? GetById(int id);
    void Add(Parent student);
    void Update(Parent student);
    void Delete(Parent student);

    void save();
}
