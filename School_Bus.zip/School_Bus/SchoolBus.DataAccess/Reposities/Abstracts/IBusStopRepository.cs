﻿

using SchoolBus.Model.Entites.Concretes;

namespace SchoolBus.DataAccess.Reposities.Abstracts;

public interface IBusStopRepository
{

    ICollection<BusStop>? GetAll();
    BusStop? GetById(int id);
    void Add(BusStop student);
    void Update(BusStop student);
    void Delete(BusStop student);

    void save();
}
