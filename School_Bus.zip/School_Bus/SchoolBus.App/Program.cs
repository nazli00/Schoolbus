﻿// See https://aka.ms/new-console-template for more information
using System;
Console.WriteLine("hello");





