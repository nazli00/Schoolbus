﻿namespace SchoolBus.Model.Entites.Abstract;

public abstract class BaseEntity
{
}
