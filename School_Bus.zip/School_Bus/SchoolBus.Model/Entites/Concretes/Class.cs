﻿using SchoolBus.Model.Entites.Abstract;
namespace SchoolBus.Model.Entites.Concretes;
public class Class:BaseEntity
{
    public int id { get; set; }
    public int num_students { get; set; }
    public int num_parents { get; set; }
    public virtual ICollection<Student>? Students { get; set; }

}
