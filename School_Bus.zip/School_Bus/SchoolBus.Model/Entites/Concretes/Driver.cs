﻿using SchoolBus.Model.Entites.Abstract;

namespace SchoolBus.Model.Entites.Concretes;
public class Driver:BaseEntity
{
    public int id { get; set; }
    public string? name { get; set; }
    public string? surname { get; set; }
    public int age { get; set; }
    public virtual ICollection<Car>? Cars { get; set; }
    public virtual ICollection<Ride>? Rides { get; set; }

}
