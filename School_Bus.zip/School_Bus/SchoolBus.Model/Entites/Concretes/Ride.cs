﻿using SchoolBus.Model.Entites.Abstract;
using System;

namespace SchoolBus.Model.Entites.Concretes;

public class Ride:BaseEntity
{
    public int id { get; set; }
    public DateTime start_time { get; set; }
    public DateTime end_time { get; set; }
    public int route_ { get; set; }
    public int car { get; set; }
    public int driver {  get; set; }
    public virtual Route? Route { get; set; }
    public virtual Car? Car { get; set; }
    public virtual Driver? Driver { get; set; }
}
