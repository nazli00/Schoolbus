﻿
using SchoolBus.Model.Entites.Abstract;

namespace SchoolBus.Model.Entites.Concretes;

public class BusStop:BaseEntity
{
    public int id { get; set; }
    public string? name { get; set; }
    public int route { get; set; }
    public virtual Route? Route { get; set; }


}
