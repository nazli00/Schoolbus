﻿using SchoolBus.Model.Entites.Abstract;
namespace SchoolBus.Model.Entites.Concretes;

public class Route:BaseEntity
{
    public int id { get; set; }
    public string? start_point { get; set; }
    public string? end_point { get; set; }
    public virtual ICollection<Ride>? Rides { get; set; }
    public virtual ICollection<BusStop>? BusStops { get; set; }
}
