﻿using SchoolBus.Model.Entites.Abstract;

namespace SchoolBus.Model.Entites.Concretes;
public class Car:BaseEntity
{
    public int id { get; set; }
    public string? bus_num { get; set; }
    public int driver { get; set; }
    public int num_seats { get; set; }
    public virtual Driver? Driver { get; set; }
    public virtual ICollection<Ride>? Rides { get; set; }

}