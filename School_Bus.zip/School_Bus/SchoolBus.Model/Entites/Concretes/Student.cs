﻿using SchoolBus.Model.Entites.Abstract;

namespace SchoolBus.Model.Entites.Concretes;

public class Student:BaseEntity
{
    public int id { get; set; }
    public string? name { get; set; }
    public string? surname { get; set; }
    public int age { get; set; }
    public int parent_ { get; set; }
    public int classid {  get; set; }
    public virtual Parent? Parent { get; set; }
    public virtual Class? Class { get; set; }
    

}
